const { Client, Authenticator } = require('minecraft-launcher-core');
const launcher = new Client();
const { app, BrowserWindow, ipcMain, webContents } = require('electron')
var $ = require('jQuery');
const fs = require('fs')
const unzipper = require('unzipper');
const sha1sum = require('sha1-sum');
const ncp = require('ncp');
const path = require('path');
const http = require('https')
const { Console, dir } = require('console');
const fetch = require('node-fetch');
let mainWindow

const createWindow = () => {
    const win = new BrowserWindow({
      width: 1100,
      height: 530,
      frame: false,
      resizable: false,
      icon: './64x64.png',
      webPreferences: {
        nodeIntegration: true,
        contextIsolation: false,
      }
    })

    mainWindow = win
  
    win.loadFile('./html/index.html')
}

app.whenReady().then(() => {
    createWindow()

    ipcMain.on('close', () => {app.exit(0)})

    init()

    app.on('activate', () => {
        if (BrowserWindow.getAllWindows().length === 0) {
          createWindow()
        }
    })
})

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') app.quit()
})

var appdataPath
var gamePath
var java_path
var assetsPath
var gameAssets
var assetsIndexPath
var tempDir
var randomSum
var runtimePath
var modsPath
var versionsPath

function init() {
 appdataPath = app.getPath('appData')
 gamePath = appdataPath + '\\\.minecraft'
 versionsPath = gamePath + '\\versions'
 if (process.platform === 'darwin') {
  os = 'osx'
 }
 else if (process.platform === 'win32') {
  os = 'windows'
 }
 else if (process.platform === 'linux') {
  os = 'linux'
 }
 arch = process.arch
 launcher_name = 'minecraft-launcher'
 launcher_version = '1.0.0'
 //  java_path = 'C:\\Users\\HURROLED\\AppData\\Roaming\\\.minecraft\\runtime\\java-runtime-gamma\\windows\\java-runtime-gamma\\bin\\java\.exe'
 java_path = 'javaw'
 assetsPath = gamePath + '\\assets'
 assetsIndexPath = assetsPath + '\\indexes'
 tempDir = app.getPath('temp')
 randomSum = Math.floor(Math.random() * 1000000000)
 runtimePath = gamePath + '\\runtime'
 gameAssets = assetsPath + '\\virtual\\legacy'
 modsPath = gamePath + '\\mods'
}

function checkHash(path, hash, callback)
{
  if (fs.existsSync(path)) {
    sha1sum(path).then(sum => {
      console.log(path)
      console.log(sum)
      console.log(hash)
      if (sum === hash) {
        callback(true)
      } else {
        callback(false)
      }
    })
  } else {
    callback(false)
  }
}

function downloadFile(url, path, callback) {
    var http = require('https');
    var fs = require('fs');
  
    var file = fs.createWriteStream(path);
    var request = http.get(url, function(response) {
      response.pipe(file, { end: false });
      response.on('end', function(e){
        console.log(response['statusCode'])
        console.log(response['req']['host'])
        if(response['statusCode'] === 302)
        {
          if(response['req']['host'] === 'edge.forgecdn.net') {
            console.log(response['rawHeaders'][response['rawHeaders'].length-1])
            file.close(() => {
              downloadFile(response['rawHeaders'][response['rawHeaders'].length-1], path, callback)
            })
          } else if(response['req']['host'] === 'github.com') {
            console.log(response['rawHeaders'][9])
            file.close(() => {
              downloadFile(response['rawHeaders'][9], path, callback)
            })
          }
        }
        else
        {
          file.close(() => {
            callback('success', path, url)
          })
        }
      })
  
      request.on('error', function(err) {
        file.close(() => {
          if (err.code === "ECONNRESET") {
            console.log("ECONNRESET error");
            callback('err', null, null)
            //specific error treatment
          }
          //other error treatment
        })
      });
    });

  }

async function downloadFileAsync(url, path)
{
  return new Promise((resolve, reject) => {
    let file = fs.createWriteStream(path);
    let request = http.get(url, (response) => {
      response.pipe(file, { end: false });

      response.on('end', () => {
        if(response['statusCode'] === 302)
        {
          if(response['req']['host'] === 'edge.forgecdn.net') {
            console.log(response['rawHeaders'][response['rawHeaders'].length - 1]);
            file.close(() => {
              downloadFileAsync(response['rawHeaders'][response['rawHeaders'].length - 1], path).then(() => {
                resolve('success');
              });
            });
          } else if(response['req']['host'] === 'github.com') {
            console.log(response['rawHeaders'][9]);
            file.close(() => {
              downloadFileAsync(response['rawHeaders'][9], path).then(() => {
                resolve('success');
              });
            });
          }
        }
        else
        {
          file.close(() => {
            resolve('success');
          });
        }
      });

      request.on('error', function(err) {
        file.close(() => {
          reject(err);
        })
      });
    });
  });
}

  let launching = 0
function downloadVersion(id, userName, javaPath, forge, custom, server, path) {
  console.log('downloadVersion');

  console.log(`Custom: ${custom}`)
  console.log(`Server: ${server}`)
  console.log(`Forge: ${forge}`)
  console.log(`PATH: ${path}`)
  
  if(launching != 1)
  {
    launching = 1
    mainWindow.webContents.send('set-status', 'Запуск Minecraft...')

    let opts = {
        clientPackage: null,
        // For production launchers, I recommend not passing 
        // the getAuth function through the authorization field and instead
        // handling authentication outside before you initialize
        // MCLC so you can handle auth based errors and validation!
        authorization:
        {
            access_token: 'null',
            client_token: '',
            uuid: 'f2f54265a0eb4dc08ff00ed893072170',
            name: userName,
            user_properties: '{}',
            meta: {
                type: 'mojang',
                demo: false
            }
        },
        javaPath: javaPath,
        // javaPath: 'java',
        root: gamePath,
        version: {
          number: id,
          custom: custom,
          type: "release"
        },
        forge: forge,
        memory: {
            max: "6G",
            min: "4G"
        },
        overrides: {
          //gameDirectory: `${gamePath}\\forge\\${id}`,
          natives: `${gamePath}\\versions\\${custom}\\natives`
        }
    }

    if(server != "") {
      opts['server'] = { host: server };
    }

    if(typeof path !== 'undefined') {
      opts['root'] = path;
      opts['overrides']['natives'] = `${path}\\versions\\${custom}\\natives`
    }
    
    console.log(javaPath)
    console.log(forge)
    console.log(id)


    launcher.launch(opts);

    mainWindow.webContents.send('set-status', 'Запуск Майнкрафта...')
  }
    
}

launcher.on('debug', (e) => 
    {
      console.log('[DEBUG] '+ e)
      if(e.endsWith('download assets')) {
        mainWindow.webContents.send('set-status', 'Загрузка ассетов...')
      } else if(e.endsWith('version json, this might take a bit')) {
        mainWindow.webContents.send('set-status', 'Генерация файлов. Это может занять много времени!')
      } else if(e.endsWith('download Minecraft version jar')) {
        mainWindow.webContents.send('set-status', 'Загрузка версии...')
      }
      
    });

    launcher.on('data', (e) => 
    {
      console.log('[MINECRAFT] ' + e)

      // let unzipPath = `${tempDir}\\java-runtime-temp\\unzip`
      // if(fs.existsSync(unzipPath))
      // {
      //   let jdkDir = fs.readdirSync(unzipPath)
      //   for(let i in jdkDir) {
      //     fs.rmSync(`${unzipPath}\\${jdkDir[i]}`, { recursive: true, force: true });
        
      //     console.log(`${`${unzipPath}\\${jdkDir[i]}`} is deleted!`);
      //   }
      // }      

      launching = 0
      mainWindow.webContents.send('launching-end')
      mainWindow.webContents.send('set-status', '')
    });

ipcMain.on('download-version', (e, id, userName,server) => {
  downloadVersion(id, userName, java_path, forge, custom,server, path)

  console.log('download-version event. launching')
})

ipcMain.on('download-java', (e, majorVersion, callback, versionId, userName, component, forge, custom, server) =>
{
  console.log('DJ' + server)
  downloadJava(e, majorVersion, callback, versionId, userName, component, forge, custom, server)
})


function deleteFolder(path) {
  let files = [];
  if( fs.existsSync(path) ) {
      files = fs.readdirSync(path);
      files.forEach(function(file,index){
          let curPath = path + "/" + file;
          if(fs.statSync(curPath).isDirectory()) {
              deleteFolder(curPath);
          } else {
              fs.unlinkSync(curPath);
          }
      });
      fs.rmdirSync(path);
  }
}


var downloadJava = (e, majorVersion, callback, versionId, userName, component, forge, custom, server, path) => {
  console.log('downloadJava');
  
  mainWindow.webContents.send('set-status', 'Загрузка Java...')

  if(typeof path != 'undefined') {
    if(!path.includes('\\')) {
      path = appdataPath + "\\" + path
    }
  }

  let link = null
  let parsePath = `${tempDir}\\java-runtime-temp`
  let unzipPath = `${tempDir}\\java-runtime-temp\\unzip\\${component}`
  let downloadPath = null
  let legacy_switch = 0
  let hash = null

  if(typeof(majorVersion) === 'string') {
    console.log("PIZDA");
    majorVersion = Number(majorVersion)
  }

  console.log("majorVersion: "+majorVersion);
  switch(majorVersion) {
    case 8:
      legacy_switch = 1
      break;
    case 16:
      link = 'https://github.com/adoptium/temurin16-binaries/releases/download/jdk-16.0.2%2B7/OpenJDK16U-jdk_x64_windows_hotspot_16.0.2_7.zip'
      downloadPath = `${parsePath}\\openjdk-16.0.2_windows-x64_bin.zip`
      hash = '3171b4bb3c7a8a5a0749d68c9343f9e2efb04ed9'
      break;
    case 17:
      console.log("downloadPath: "+downloadPath);
      link = 'https://github.com/adoptium/temurin17-binaries/releases/download/jdk-17.0.6%2B10/OpenJDK17U-jre_x64_windows_hotspot_17.0.6_10.zip'
      downloadPath = `${parsePath}\\jdk-17_windows-x64_bin.zip`
      hash = '2ec836d7897d3925b8245a7035d70899adbf0b0e'
      console.log("downloadPath: "+downloadPath);
      break;
    case 18:
      link = 'https://github.com/adoptium/temurin18-binaries/releases/download/jdk-18.0.2.1%2B1/OpenJDK18U-jre_x64_windows_hotspot_18.0.2.1_1.zip'
      downloadPath = `${parsePath}\\jdk-18.0.2_windows-x64_bin.zip`
      hash = '9725d2296e5c855f2f6d66490fc3b4cd2b20ae7d'
      break;
    default:
      console.log('default');
      break;
  }

  console.log("downloadPath: "+downloadPath);

  function downloadJv() {
    console.log('downloadJv in downloadJava');

    downloadFile(link, downloadPath, function(status) {
      if (status === 'success') {
        console.log(`java ${majorVersion} downloaded at ${link} and put to ${downloadPath}`)
        let stream = fs.createReadStream(downloadPath).pipe(unzipper.Extract({ path: unzipPath }));
        stream.on('finish', () => {
          fs.mkdir(`${runtimePath}\\${component}\\windows\\${component}`, { recursive: true }, err => {
            ncp(`${unzipPath}`, `${runtimePath}\\${component}\\windows`, function (err) {
              java_path = `${runtimePath}\\${component}\\windows\\${component}\\bin\\javaw.exe`
              downloadVersion(versionId, userName, java_path, forge, custom,server, path);
              console.log('downloaded fully. launching')
            })
          })

          java_path = `${runtimePath}\\${component}\\windows\\${component}\\bin\\javaw.exe`
          // downloadVersion(versionId, userName, java_path, forge, custom,server, path);
          console.log('downloadjv. launching')
        })
      }
    })
  }

  let i = 0
  function moveCount(filesCount)
  {
    i++

    console.log(`${i}/${filesCount}`)

    if(i === filesCount)
    {
      java_path = `${runtimePath}\\${component}\\windows\\${component}\\bin\\javaw.exe`
      downloadVersion(versionId, userName, java_path, forge, custom,server, path)
      console.log('downloaded fully. launching')
    }
  }

  if(legacy_switch === 0 && majorVersion != null)
  {
    fs.mkdir(unzipPath, {recursive: true}, err => {
      try {
        if (fs.existsSync(downloadPath)) {
          sha1sum(downloadPath).then(sum => {
            console.log(sum)
            console.log(hash)
            if (sum === hash)
            {
              console.log('hash is working')
              console.log(majorVersion)
              console.log(downloadPath)
              console.log(unzipPath)
              console.log(`${runtimePath}\\${component}\\windows`)

              let stream = fs.createReadStream(downloadPath).pipe(unzipper.Extract({ path: unzipPath }));
              stream.on('finish', () => {
                fs.mkdir(`${runtimePath}\\${component}\\windows\\${component}`, { recursive: true }, err => {
                  ncp(`${unzipPath}`, `${runtimePath}\\${component}\\windows`, function (err) {
                    java_path = `${runtimePath}\\${component}\\windows\\${component}\\bin\\javaw.exe`
                    downloadVersion(versionId, userName, java_path, forge, custom,server, path)
                    console.log('downloaded fully. launching')
                  })
                })
              })

              console.log('hash is working2');
            }
            else
              downloadJv()
          })
        }
        else
          downloadJv()
      } catch(err) {
        downloadJv()
      }
    })
  }
  else {
    downloadVersion(versionId, userName, "java", forge, custom,server, path)
    console.log('legacy. launching')
  }
}

ipcMain.on('install-mod', (e, url, hash, filename, minecraft) => 
{
  console.log(url)
  fs.mkdir(modsPath, { recursive: true }, err => 
  {
    console.log(`${gamePath}\\forge\\${minecraft}\\mods\\${filename}`)
    downloadFile(url, `${modsPath}\\${filename}`, function callback(status)
    {
      if (status === 'success')
      {
        mainWindow.webContents.send('set-status', 'Мод установлен успешно.')
      }
    })
  })
})

ipcMain.on('check-offline', () => {
  checkOffline()
})

async function downloadJSON(url) {
  return new Promise((resolve) => {
    fetch(url, { method: "Get" })
      .then(res => res.json())
      .then((json) => {
        resolve(json);
      })
  });
}

async function checkOffline()
{
  let versionsList = []
  if (fs.existsSync(versionsPath))
  {
    var files = fs.readdirSync(versionsPath);
    for (var i in files)
    {
      if (fs.statSync(`${versionsPath}\\${files[i]}`).isDirectory())
      {
        if(fs.existsSync(`${versionsPath}\\${files[i]}\\${files[i]}\.json`))
        {
          versionJSON = JSON.parse(fs.readFileSync(`${versionsPath}\\${files[i]}\\${files[i]}\.json`))
          //console.log(versionJSON.assets)

          let time = null
          let version = versionJSON.inheritsFrom
          let component;
          let majorVersion;
          let inheritsFrom;

          if(typeof versionJSON.inheritsFrom !== 'undefined') {
            try {
              await fs.promises.access(`${versionsPath}\\${files[i]}\\${versionJSON.inheritsFrom}\.json`, fs.F_OK)
            
              console.log(`Inherit file is already present in path: ${versionsPath}\\${files[i]}\\${versionJSON.inheritsFrom}\.json`);

              let inheritsFrom = JSON.parse(fs.readFileSync(`${versionsPath}\\${files[i]}\\${versionJSON.inheritsFrom}\.json`, versionJSON));
              Object.assign(inheritsFrom, versionJSON);  // merging two jsons
              versionJSON = inheritsFrom;
            } catch (error) {
              console.log(`InheritsFrom JSON for ${versionJSON.id} does not exist in current directory. Downloading vanilla one.`)
            
              let versionsJSON = await downloadJSON('https://launchermeta.mojang.com/mc/game/version_manifest.json')

              // console.log(versionsJSON)
              console.log(`Version manifest downloaded, searching for ${versionJSON.inheritsFrom} for version ${versionJSON.id}.`)

              for (version in versionsJSON.versions) {
                if (versionsJSON.versions[version].id == versionJSON.inheritsFrom) {
                  console.log(`Version ${versionJSON.inheritsFrom} found for ${versionJSON.id}. Downloading JSON from URL ${versionsJSON.versions[version].url}, to path ${versionsPath}\\${files[i]}\\${versionJSON.inheritsFrom}\.json.`)
                  let downloadError = await downloadFileAsync(versionsJSON.versions[version].url, `${versionsPath}\\${files[i]}\\${versionJSON.inheritsFrom}\.json`);
                  
                  if(downloadError == 'success') {
                    console.log(`Downloaded ${versionJSON.inheritsFrom}.json for ${versionJSON.id} from URL ${versionsJSON.versions[version].url}, to path ${versionsPath}\\${files[i]}\\${versionJSON.inheritsFrom}\.json.`)
                    
                    try {
                      await fs.promises.access(`${versionsPath}\\${files[i]}\\${versionJSON.inheritsFrom}\.json`, fs.F_OK)

                      console.log(`Path ${versionsPath}\\${files[i]}\\${versionJSON.inheritsFrom}\.json exists! Version: ${versionJSON.id}`)
                      
                      inheritsFrom = JSON.parse(fs.readFileSync(`${versionsPath}\\${files[i]}\\${versionJSON.inheritsFrom}\.json`, versionJSON));
                      Object.assign(inheritsFrom, versionJSON);  // merging two jsons
                      versionJSON = inheritsFrom;
                    } catch (error) {
                      console.error(`Exists error: ${error}`)
                    }
                  }
                }
              }
            }
          }

          //console.log(versionJSON)
          mainWindow.webContents.send('console', versionJSON);

          if(typeof versionJSON.javaVersion !== 'undefined') {
            component = versionJSON.javaVersion.component;
            majorVersion = versionJSON.javaVersion.majorVersion;
          } else {
            component = 'jre-legacy';
            majorVersion = 8;
          }

          versionsList.push([versionJSON.id, files[i], version, time, component, majorVersion])
        }
      }
    }
  }

  checkModPacks((packs) => {
    console.log(versionsList)
    mainWindow.webContents.send('offline-versions', versionsList, packs)
  })
}

ipcMain.on('download-forge', (e, url, hash, id, minecraft, username, java, component, server, path) =>
{
  mainWindow.webContents.send('set-status', 'Загрузка Forge...')
  forgesPath = `${gamePath}\\forges`
  
  fs.mkdir(forgesPath, { recursive: true }, err => 
  {
    if (fs.existsSync(`${forgesPath}\\${id}.jar`)) {
      sha1sum(`${forgesPath}\\${id}.jar`).then(sum => 
      {
        if(sum === hash)
        {
          downloadJava(null, java, null, minecraft, username, component, `${forgesPath}\\${id}.jar`, null, server, path)
        }
        else
        {
          downloadFile(url, `${forgesPath}\\${id}.jar`, () => 
          {
            downloadJava(null, java, null, minecraft, username, component, `${forgesPath}\\${id}.jar`,null,server, path)
          })
        }
      })
    }
    else
    {
      downloadFile(url, `${forgesPath}\\${id}.jar`, () => 
      {
        downloadJava(null, java, null, minecraft, username, component, `${forgesPath}\\${id}.jar`,null,server, path)
      })
    }
  })
})

function installModPack(dir, modsJ, version, name) {
  let path = appdataPath + "\\" + dir + "\\mods\\"
  if (!fs.existsSync(appdataPath + "\\" + dir + "\\mods")){
    fs.mkdirSync(appdataPath + "\\" + dir + "\\mods", { recursive: true });
  }

  let modpack = {
    "name": name,
    "directory": dir,
    "version": version,
    "mods": modsJ
  }

  fs.access(gamePath + "\\modpacks.json", fs.F_OK, (err) => {
    if (err) {
      let mps = {
        "modpacks": []
      }
      mps.modpacks.push(modpack)
    
      fs.appendFileSync(gamePath + "\\modpacks.json", JSON.stringify(mps))
    }

    let packs = JSON.parse(fs.readFileSync(gamePath + "\\modpacks.json"))
    for (var pack in packs.modpacks) {
      if (packs.modpacks[pack].directory == dir) {
        console.log("already present!!")
        packs.modpacks.splice(pack, 1);
      }
    }

    packs.modpacks.push(modpack)

    fs.writeFileSync(gamePath + "\\modpacks.json", JSON.stringify(packs))
    console.log(JSON.stringify(packs))
  })

  let j = 0;
  let mods = JSON.parse(modsJ)
  let modsToDownload = []

  for (let mod in mods) {
    j++
    checkHash(path+mods[mod].filename, mods[mod].sha1, (ok) => {
      console.log(ok)
      if(ok == false) {
        console.log("File not downloaded.")
        modsToDownload.push(mods[mod])
      }

      j--
      
      if(j == 0) {
        console.log(modsToDownload)
        let i = 0;
        if(modsToDownload.length === 0) {
          if(i == 0) {
            console.log(`Modpack ${dir} downloaded fully.`)
            checkOffline()
            mainWindow.webContents.send('check-modpacks')
          }
        } else {
          for (let mod in modsToDownload) {
            i++
            downloadFile(modsToDownload[mod].url, path+modsToDownload[mod].filename, () => {
              i--
              console.log(`Mod ${modsToDownload[mod].filename} downloaded.`)
              if(i == 0) {
                console.log(`Modpack ${dir} downloaded fully.`)
                checkOffline()
                mainWindow.webContents.send('check-modpacks')
              }
            })
          }
        }
      }
    })
  }
}

ipcMain.on('delete-modpack', (e, dir) => {
  fs.access(gamePath + "\\modpacks.json", fs.F_OK, (err) => {
    if (err) {
      return
    }

    let packs = JSON.parse(fs.readFileSync(gamePath + "\\modpacks.json"))
    for (var pack in packs.modpacks) {
      if(packs.modpacks[pack].directory == dir) {
        packs.modpacks.splice(pack, 1);
      }
    }

    fs.writeFileSync(gamePath + "\\modpacks.json", JSON.stringify(packs))
  })

  fs.rmSync(appdataPath + "\\" + dir, { recursive: true, force: true });

  checkOffline()
  mainWindow.webContents.send('check-modpacks')
})

ipcMain.handle('check-modpacks', async (event) => {
  let packs = await checkModpacks();
  return packs;
})

function checkModpacks() {
  return new Promise(resolve => {
    fs.access(gamePath + "\\modpacks.json", fs.F_OK, (err) => {
      if (err) {
        resolve({"modpacks": []})
        return
      }

      let packs = JSON.parse(fs.readFileSync(gamePath + "\\modpacks.json"))
      resolve(packs)
    })
  })
}

function checkModPacks(callback) {
  fs.access(gamePath + "\\modpacks.json", fs.F_OK, (err) => {
    if (err) {
      callback({"modpacks": []})
      return
    }

    let packs = JSON.parse(fs.readFileSync(gamePath + "\\modpacks.json"))

    // for (var pack in packs.modpacks) {
    //   let dir = packs.modpacks[pack].directory
    //   let path = appdataPath + "\\" + dir + "\\mods\\"
    //   console.log(dir)
    //   let j = 0;
    //   let modsToDownload = []

    //   let mods = JSON.parse(packs.modpacks[pack].mods)
    
    //   for (let mod in mods) {
    //     j++
    //     checkHash(path+mods[mod].filename, mods[mod].sha1, (ok) => {
    //       console.log(ok)
    //       if(ok == false) {
    //         console.log("File not downloaded.")
    //         modsToDownload.push(mods[mod])
    //       }
    
    //       j--
          
    //       if(j == 0) {
    //         console.log(modsToDownload)
    //         let i = 0;
    //         if(modsToDownload.length === 0) {
    //           if(i == 0) {
    //             console.log(`Modpack ${dir} checked fully.`)
    //             callback(packs)
    //           }
    //         } else {
    //           for (let mod in modsToDownload) {
    //             i++
    //             downloadFile(modsToDownload[mod].url, path+modsToDownload[mod].filename, () => {
    //               i--
    //               console.log(`Mod ${modsToDownload[mod].filename} downloaded.`)
    //               if(i == 0) {
    //                 console.log(`Modpack ${dir} checked fully.`)
    //                 callback(packs)
    //               }
    //             })
    //           }
    //         }
    //       }
    //     })
    //   }
    // }

    callback(packs)
  })

  // let i = 0;
  // let mods = JSON.parse(modsJ)
  // for (let mod in mods) {
  //   i++
  //   if(!checkHash(path+mods[mod].filename, mods[mod].sha1)) {
  //     downloadFile(mods[mod].url, path+mods[mod].filename, () => {
  //       i--
  //       console.log(`Mod ${mods[mod].filename} downloaded.`)
  //       if(i == 0) {
  //         console.log(`Modpack ${dir} downloaded fully.`)
  //       }
  //     })
  //   } else {
  //     i--

  //     if(i == 0) {
  //       console.log(`Modpack ${dir} downloaded fully.`)
  //     }
  //   }
  // }
}

ipcMain.on('start-offline', (e, minecraft, username, java, component, custom, server, forge) => 
{
  downloadJava(null, java, null, minecraft, username, component, forge, custom, server)
})

ipcMain.on('installModPack', (e, dir, mods, version, name) => 
{
  installModPack(dir, mods, version, name)
})

ipcMain.on('delete-mods', (e, id) => {
  let directory = modsPath;

  fs.readdir(directory, (err, files) => {
    if (err) throw err;

    for (const file of files) {
      fs.unlink(path.join(directory, file), err => {
        if (err) throw err;
      });
    }
  });
});

var modpack;

ipcMain.handle('init-modpack', async (event, modpackName, modpackVersion, modpackMods, modpackDirectory) => {
  return new Promise((resolve, reject) => {
    modpack = new Modpack(modpackName, modpackVersion, modpackMods, modpackDirectory);

    resolve(modpack);  // resolving backend class to renderer
  });
});

ipcMain.handle('add-modpack', async (event) => {
  const addResult = await modpack.addModpackJSON();

  return addResult;
});

ipcMain.handle('download-modpack', async (event) => {
  const downloadResult = await modpack.downloadModpack();

  return downloadResult;
});

ipcMain.handle('remove-modpack', async (event) => {
  return modpack.removeModpack();
});

class Modpack
{
  constructor(modpackName, modpackVersion, modpackMods, modpackDirectory) {
    this.name = modpackName;
    this.version = modpackVersion;
    this.mods = modpackMods;
    this.directory = modpackDirectory;

    // CreatedModpackPath class will help us to easily get pathes we need
    this.path = new Path(appdataPath, this.directory, 'mods',
      '.minecraft', 'modpacks.json');

    this.file = new File();  // File class is simpler Node.js fs wrap, it can also check hashes, etc...
  }

  // this method directly adds class parameters into modpacks.json file
  async addModpackJSON() {
    let JSONPath = await this.path.getJSONPath();

    // our new modpack object to add to JSON file
    let modpack = {
      "name": this.name,
      "directory": this.directory,
      "version": this.version,
      "mods": this.mods
    }
    
    if (await this.file.writable(JSONPath)) {
      let modpacks;  // array that already contains in the modpacks.json
      
      modpacks = JSON.parse(await this.file.readFile(JSONPath));  // reading modpacks from file

      if(!modpacks.modpacks.includes(modpack)) {
        modpacks.modpacks.push(modpack);  // pushing our modpack into the object
      }
      

      return this.file.writeStringToFile(JSONPath, JSON.stringify(modpacks));  // writing the object to file
    } else {
      if (!(await this.file.exists(JSONPath))) {
        let modpacks = {
          "modpacks": [
            modpack
          ]
        }

        return this.file.writeStringToFile(JSONPath, JSON.stringify(modpacks));  // writing the object to file
      } else {
        console.error('Writing to modpacks.json is not permitted.');

        return Promise.reject(false);
      }
    }
  }

  async createModpackDirectory() {
    return this.file.createDirectory(await this.path.getModsPath());  // creating modpacks and mods directories
  }

  async downloadModpack() {
    await this.createModpackDirectory();

    let downloadPromisesArray = [];  // array of downloadFileAsync promises to know when they all resolved

    for (let mod in this.mods) {
      let modPath = await this.path.getModPath(this.mods[mod].filename);
      let modUrl = this.mods[mod].url;
      let modHash = this.mods[mod].sha1;

      if ((await this.file.checkHash(modPath, modHash)) === false) {  // checking file hashes
        downloadPromisesArray.push(downloadFileAsync(modUrl, modPath));  // downloading file if hashes do not coincide
      }
    }

    let allFilesDownloadedPromise = Promise.all(downloadPromisesArray);  // checking if mods downloaded

    checkOffline();

    return allFilesDownloadedPromise;
  }

  async removeModpackFromJSON() {
    let JSONPath = await this.path.getJSONPath();

    if (await this.file.writable(JSONPath)) {
      let modpacks;  // array that already contains in the modpacks.json
      
      modpacks = JSON.parse(await this.file.readFile(JSONPath));  // reading modpacks from file
      
      for(modpack in modpacks.modpacks) {
        if(modpacks.modpacks[modpack]['directory'] == this.directory) {
          modpacks.modpacks.splice(modpack, 1);  // removing this modpack
        }
      }

      return this.file.writeStringToFile(JSONPath, JSON.stringify(modpacks));  // writing the object to file
    }
  }

  async removeModpack() {
    this.file.removeDirectory(await this.path.getModpackPath());

    checkOffline();

    return this.removeModpackFromJSON();
  }
}

class Path
{
  constructor(appdataPath, modpackDirectory, modsDirectory, minecraftDirectory, modpacksJSONName) {
    this.appdataPath = appdataPath;
    this.modpackDirectory = modpackDirectory;
    this.modsDirectory = modsDirectory;
    this.minecraftDirectory = minecraftDirectory;
    this.modpacksJSONName = modpacksJSONName;
  }

  async getAppdataPath() {
    return this.appdataPath;
  }

  async getJSONPath() {
    return `${this.appdataPath}\\${this.minecraftDirectory}\\${this.modpacksJSONName}`;
  }

  async getModsPath() {
    return `${this.appdataPath}\\${this.modpackDirectory}\\${this.modsDirectory}`;
  }

  async getModPath(modFileName) {
    return `${this.appdataPath}\\${this.modpackDirectory}\\${this.modsDirectory}\\${modFileName}`;
  }

  async getModpackPath() {
    return `${this.appdataPath}\\${this.modpackDirectory}`;
  }
}

class File
{
  async exists(filePath) {
    try {
      await fs.promises.access(filePath, fs.constants.F_OK);  // just check file's existance

      return true;
    } catch (error) {
      return false;
    }
  }

  async writable(filePath) {
    try {
      await fs.promises.access(filePath, fs.constants.R_OK | fs.constants.W_OK);  // check read and write permissons

      return true;
    } catch (error) {
      return false;
    }
  }

  async readFile(filePath) {
    try {
      const contents = await fs.promises.readFile(filePath, { encoding: 'utf8' });
      return contents;
    } catch (error) {
      return error;
    }
  }

  async createDirectory(directoryPath) {
    return fs.promises.mkdir(directoryPath, { recursive: true });
  }

  async removeDirectory(directoryPath) {
    return fs.promises.rm(directoryPath, { recursive: true });
  }

  async writeStringToFile(filePath, stringToAdd) {
    return fs.promises.writeFile(filePath, stringToAdd, { encoding: 'utf-8' });
  }

  async checkHash(filePath, hashToCheck) {
    try {
      await fs.promises.access(filePath, fs.constants.F_OK);

      sha1sum(filePath).then(fileHash => {
        if (fileHash === hashToCheck) {
          return true;
        } else {
          return false;
        }
      })
    } catch (error) {
      return false;
    }
  }
}

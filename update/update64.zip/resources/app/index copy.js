const { Client, Authenticator } = require('minecraft-launcher-core');
const launcher = new Client();
const { app, BrowserWindow, ipcMain } = require('electron')
var $ = require('jQuery');
var fs = require('fs');
const unzipper = require('unzipper');
const sha1sum = require('sha1-sum');
const ncp = require('ncp');
const path = require('path');
const { Console } = require('console');
let mainWindow

const createWindow = () => {
    const win = new BrowserWindow({
      width: 1100,
      height: 600,
      frame: false,
      // resizable: false,
      webPreferences: {
        nodeIntegration: true,
        contextIsolation: false,
      }
    })

    mainWindow = win
  
    win.loadFile('./html/index.html')
}

app.whenReady().then(() => {
    createWindow()

    ipcMain.on('close', () => {app.exit(0)})

    init()

    app.on('activate', () => {
        if (BrowserWindow.getAllWindows().length === 0) {
          createWindow()
        }
    })
})

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') app.quit()
})

var appdataPath
var gamePath
var java_path
var assetsPath
var gameAssets
var assetsIndexPath
var tempDir
var randomSum
var runtimePath
var modsPath

function init() {
 appdataPath = app.getPath('appData')
 gamePath = appdataPath + '\\\.minecraft'
 versionsPath = gamePath + '\\versions'
 if (process.platform === 'darwin') {
  os = 'osx'
 }
 else if (process.platform === 'win32') {
  os = 'windows'
 }
 else if (process.platform === 'linux') {
  os = 'linux'
 }
 arch = process.arch
 launcher_name = 'minecraft-launcher'
 launcher_version = '1.0.0'
 //  java_path = 'C:\\Users\\HURROLED\\AppData\\Roaming\\\.minecraft\\runtime\\java-runtime-gamma\\windows\\java-runtime-gamma\\bin\\java\.exe'
 java_path = 'java'
 assetsPath = gamePath + '\\assets'
 assetsIndexPath = assetsPath + '\\indexes'
 tempDir = app.getPath('temp')
 randomSum = Math.floor(Math.random() * 1000000000)
 runtimePath = gamePath + '\\runtime'
 gameAssets = assetsPath + '\\virtual\\legacy'
 modsPath = gamePath + '\\mods'
}

function downloadFile(url, path, callback) {
    var http = require('https');
    var fs = require('fs');
  
    var file = fs.createWriteStream(path);
    var request = http.get(url, function(response) {
      response.pipe(file, { end: false });
      response.on('end', function(e){
        callback('success', path, url)
      })
  
      request.on('error', function(err) {
        if (err.code === "ECONNRESET") {
          console.log("ECONNRESET error");
          callback('err', null, null)
          //specific error treatment
        }
        //other error treatment
      });
    });
  }

function downloadVersion(id, userName, javaPath, forge) {
    mainWindow.webContents.send('set-status', 'Запуск Minecraft...')

    let opts = {
        clientPackage: null,
        // For production launchers, I recommend not passing 
        // the getAuth function through the authorization field and instead
        // handling authentication outside before you initialize
        // MCLC so you can handle auth based errors and validation!
        authorization:
        {
            access_token: 'null',
            client_token: '',
            uuid: 'f2f54265a0eb4dc08ff00ed893072170',
            name: userName,
            user_properties: '{}',
            meta: {
                type: 'mojang',
                demo: false
            }
        },
        javaPath: javaPath,
        // javaPath: 'java',
        root: gamePath,
        version: {
            number: id,
            type: "release",
            custom: "Flux B13"
        },
        forge: forge,
        memory: {
            max: "6G",
            min: "4G"
        }
    }
    
    console.log(javaPath)
    console.log(forge)
    console.log(id)

    mainWindow.webContents.send('launching-end')
    mainWindow.webContents.send('set-status', '')

    launcher.launch(opts);
    
    launcher.on('debug', (e) => console.log(e));
    launcher.on('data', (e) => console.log(e));
}

ipcMain.on('download-version', (e, id, userName) => {
  console.log('download-version event. launching')
  downloadVersion(id, userName, java_path, forge)
})

ipcMain.on('download-java', (e, majorVersion, callback, versionId, userName, component, forge) =>
{
  downloadJava(e, majorVersion, callback, versionId, userName, component, forge)
})

var downloadJava = (e, majorVersion, callback, versionId, userName, component, forge) => {
  mainWindow.webContents.send('set-status', 'Загрузка Java...')

  let link = null
  let parsePath = `${tempDir}\\java-runtime-temp`
  let unzipPath = `${tempDir}\\java-runtime-temp\\unzip`
  let downloadPath = null
  let legacy_switch = 0
  let hash = null
  let java_name
  let entry = 0
  switch(majorVersion) {
    case 8:
      legacy_switch = 1
      break;
    case 16:
      link = 'https://drive.google.com/uc?export=download&id=1EasPA4irAsccKfHK5Zq5M_TDy4KsKvGS&confirm=t&uuid=642fdc74-258b-4e15-b041-6623a70c7ba2'
      downloadPath = `${parsePath}\\jdk-16.0.2_windows-x64_bin.zip`
      hash = 'e7591dc603720fde2170b9643ce544faae7b801a'
      break;
    case 17:
      link = 'https://download.oracle.com/java/17/latest/jdk-17_windows-x64_bin.zip'
      downloadPath = `${parsePath}\\jdk-17_windows-x64_bin.zip`
      hash = 'b60955a4df544422b8895e8c2506920416cc4cd7'
      break;
    case 18:
      link = 'https://download.oracle.com/java/18/archive/jdk-18.0.2_windows-x64_bin.zip'
      downloadPath = `${parsePath}\\jdk-18.0.2_windows-x64_bin.zip`
      hash = '7620de255969d129f29b37a458ac3cdafb1b532f'
      break;
  }

  function downloadJv() {
    downloadFile(link, downloadPath, function(status) {
      if (status === 'success') {
        console.log(`java ${majorVersion} downloaded at ${link} and put to ${downloadPath}`)

        fs.createReadStream(downloadPath)
        .pipe(unzipper.Parse())
        .on('entry', function (entry) {
          java_name = entry.path;

          let stream = fs.createReadStream(downloadPath).pipe(unzipper.Extract({ path: unzipPath }));
          stream.on('finish', () => {
            // let jdkDir = fs.readdirSync(unzipPath)
            // for(let i in jdkDir) {
              let files = fs.readdirSync(`${unzipPath}\\${java_name}`)
              for(let j in files) 
              {
                console.log(`${runtimePath}\\${component}\\windows\\${component}\\${files[j]}`)
                if(files[j].includes('.'))
                {
                  fs.mkdir(`${runtimePath}\\${component}\\windows\\${component}`, { recursive: true }, err => {
                    ncp(`${unzipPath}\\${java_name}\\${files[j]}`, `${runtimePath}\\${component}\\windows\\${component}\\${files[j]}`, function (err) {
                      if (err) { return console.error(err); }
                    });
                  })
                }
                else
                {
                  fs.mkdir(`${runtimePath}\\${component}\\windows\\${component}\\${files[j]}`, { recursive: true }, err => {
                    ncp(`${unzipPath}\\${java_name}\\${files[j]}`, `${runtimePath}\\${component}\\windows\\${component}\\${files[j]}`, function (err) {
                      if (err) { return console.error(err); }
                    });
                  })
                }
              }
            // }

            java_path = `${runtimePath}\\${component}\\windows\\${component}\\bin\\java.exe`
            downloadVersion(versionId, userName, java_path, forge)
            console.log('downloadjv. launching')
          })
        });
      }
    })
  }

  let i = 0
  function moveCount(filesCount)
  {
    i++

    console.log(`${i}/${filesCount}`)

    if(i === filesCount)
    {
      java_path = `${runtimePath}\\${component}\\windows\\${component}\\bin\\java.exe`
      downloadVersion(versionId, userName, java_path, forge)
      console.log('downloaded fully. launching')
    }
  }

  if(legacy_switch === 0 && majorVersion != null)
  {
    fs.mkdir(unzipPath, {recursive: true}, err => {
      try {
        if (fs.existsSync(downloadPath)) {
          sha1sum(downloadPath).then(sum => {
            console.log(sum)
            console.log(hash)
            if (sum === hash)
            {
              console.log('hash is working')

              let stream = fs.createReadStream(downloadPath).pipe(unzipper.Extract({ path: unzipPath }));
              
              stream.on('finish', () => {
                fs.createReadStream(downloadPath)
                .pipe(unzipper.Parse())
                .on('entry', function (entry) {
                  java_name = entry.path;
                  var arr = java_name.split('/')
                  if(entry !== 1)
                  {
                    entry = 1
                    if(arr[0].startsWith('jdk-'))
                    {
                      console.log(arr[0])
                      let files = fs.readdirSync(`${unzipPath}\\${arr[0]}`)
                      console.log(files)
                      let counter = 0;

                      downloaded = new Array();
                      for(let j in files) 
                      {
                        // console.log(`${runtimePath}\\${component}\\windows\\${component}\\${files[j]}`)
                        if(files[j].includes('.') || files[j] === 'release' || files[j] === 'LICENSE' || files[j] === 'README') {
                          fs.mkdir(`${runtimePath}\\${component}\\windows\\${component}`, { recursive: true }, err => {
                            
                            ncp(`${unzipPath}\\${arr[0]}\\${files[j]}`, `${runtimePath}\\${component}\\windows\\${component}\\${files[j]}`, function (err) {
                              if (err) { return console.error(err); }


                              if (!downloaded.includes(files[j]))
                              {
                                console.log(`${unzipPath}\\${arr[0]}\\${files[j]}`)
                                moveCount(counter)
                                downloaded.push(files[j]) 
                              }
                            });
                            counter++;
                            console.log(`111${unzipPath}\\${arr[0]}\\${files[j]}`)
                          })
                        }
                        else
                        {
                          fs.mkdir(`${runtimePath}\\${component}\\windows\\${component}\\${files[j]}`, { recursive: true }, err => {
                            ncp(`${unzipPath}\\${arr[0]}\\${files[j]}`, `${runtimePath}\\${component}\\windows\\${component}\\${files[j]}`, function (err) {
                              if (err) { return console.error(err); }

                              if (!downloaded.includes(files[j]))
                              {
                                console.log(`${unzipPath}\\${arr[0]}\\${files[j]}`)
                                moveCount(counter)
                                downloaded.push(files[j]) 
                              }
                            });
                            counter++;
                            console.log(`111${unzipPath}\\${arr[0]}\\${files[j]}`)
                          })
                        }
                      }
                    }
                  }
                });
              })
            }
            else
              downloadJv()
          })
        }
        else
          downloadJv()
      } catch(err) {
        downloadJv()
      }
    })
  }
  else {
    downloadVersion(versionId, userName, java_path, forge)
    entry === 0
    console.log('legacy. launching')
  }
}

ipcMain.on('install-mod', (e, url, hash, filename) => 
{
  console.log(modsPath)
  fs.mkdir(modsPath, { recursive: true }, err => 
  {
    downloadFile(url, `${modsPath}\\${filename}`, function callback(status)
    {
      if (status === 'success')
      {
        mainWindow.webContents.send('set-status', 'Мод установлен успешно.')
      }
    })
  })
})

ipcMain.on('check-offline', () =>
{
  if (fs.existsSync(versionsPath))
  {
    var files = fs.readdirSync(versionsPath);
    for (var i in files)
    {
      if (fs.statSync(`${versionsPath}\\${files[i]}`).isDirectory())
      {
        mainWindow.webContents.send('offline-version', `${files[i]}`)
      }
    }
  }
})

ipcMain.on('download-forge', (e, url, hash, id, minecraft, username) =>
{
  mainWindow.webContents.send('set-status', 'Загрузка Forge...')
  forgesPath = `${gamePath}\\forges`
  fs.mkdir(forgesPath, { recursive: true }, err => 
  {
    if (fs.existsSync(`${forgesPath}\\${id}.jar`)) {
      sha1sum(`${forgesPath}\\${id}.jar`).then(sum => 
      {
        if(sum === hash)
        {
          downloadJava(null, 17, null, minecraft, username, 'java-runtime-gamma', `${forgesPath}\\${id}.jar`)
        }
        else
        {
          downloadFile(url, `${forgesPath}\\${id}.jar`, () => 
          {
            downloadJava(null, 17, null, minecraft, username, 'java-runtime-gamma', `${forgesPath}\\${id}.jar`)
          })
        }
      })
    }
    else
    {
      downloadFile(url, `${forgesPath}\\${id}.jar`, () => 
      {
        
        downloadJava(null, 17, null, minecraft, username, 'java-runtime-gamma', `${forgesPath}\\${id}.jar`)
      })
    }
  })
})
